package com.example.senddata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import com.example.senddata.ui.login.LoginActivity;

public class MainActivity extends AppCompatActivity {

    ImageButton imageButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageButton = findViewById(R.id.careto);
        imageButton.setOnClickListener(view -> onClickSwitch(view));
    }

    public void onClickSwitch(View view) {
        //pasar datos
        EditText editext = (EditText) findViewById(R.id.cajita);
        String text = editext.getText().toString();
        Intent intent = new Intent(this, LoginActivity.class);
        intent.putExtra(intent.EXTRA_TEXT, text);
        startActivity(intent);


    }
}