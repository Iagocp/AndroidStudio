package com.example.bottom_navegation.ui.megabottom;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class MegaBottomViewModel extends ViewModel {
    private final MutableLiveData<String> mText;

    public  MegaBottomViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is MegaBottom fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}

