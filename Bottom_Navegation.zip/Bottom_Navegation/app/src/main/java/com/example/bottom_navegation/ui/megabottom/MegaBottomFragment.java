package com.example.bottom_navegation.ui.megabottom;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.bottom_navegation.databinding.FragmentMegabottomBinding;

public class MegaBottomFragment extends Fragment {


    private FragmentMegabottomBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        MegaBottomViewModel megaBottomViewModel =
                new ViewModelProvider(this).get(MegaBottomViewModel.class);

        binding = FragmentMegabottomBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textMegabottom;
        megaBottomViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}

